# nodejs-concurrent_request
可以刷一个小网站的流量，可以导致该站打不开错误502
